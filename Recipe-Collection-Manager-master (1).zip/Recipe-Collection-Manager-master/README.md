# Recipe Collection Manager
* Based on the assignment guidelines presented in IT-511 Object Oriented Application Development
* Manages ingredients and recipes for an entire collection
* Class-based
## Technologies Used
* Java
## Features
Users can add a recipe to the collection. The recipe has a list of ingredients that need to be created and added. The Recipe Box is a collection of recipes with said ingredients. The functionality allows users to add a new recipe, view the detials of a recipe, delete a recipe, or view all the recipes.
## User Stories
* Users can create a new recipe.
* Users can view the details of a recipe.
* Users can delete a recipe.
* Users can update a recipe.
* Users can add instructions to recipe.
## Goals
* Polish the syntax of the code.
* Create a way to view the various serving sizes.
